# Escrutinio 2025 - La Pampa (Autocompletado)
- Pestañas: **Cargar Datos**, **Ver Resultados**, **Resumen General**.
- Formulario: Mesa primero; autocompleta Sección y Circuito al salir del campo consultando Apps Script (`action=getLugares`).
- Resultados/Resumen: leen `action=getMesas`.
- Resumen incluye gráfico circular con votos + porcentaje y botón **Exportar a CSV** con fila de totales.
- Mantiene encabezado con logo centrado.

## Dev
npm install
npm run dev

## Build
npm run build
