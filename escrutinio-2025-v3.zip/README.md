# Escrutinio 2025 - La Pampa

## 🚀 Instrucciones
1. Instalar dependencias:
   ```bash
   npm install
   ```

2. Ejecutar localmente:
   ```bash
   npm run dev
   ```

3. Para subir a Netlify o Vercel:
   - Build command: `npm run build`
   - Output directory: `dist`

---

El formulario envía los datos a:
`https://script.google.com/macros/s/AKfycbxpZQqVIJ0D2deCvet6Ph0o4U4YgMu5MHyuTjDYyqpnHZOUTINjy8GaD1yThZe4dgWJdw/exec`
