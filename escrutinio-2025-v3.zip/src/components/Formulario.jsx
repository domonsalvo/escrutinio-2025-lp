import React, { useState } from 'react'

export default function Formulario() {
  const [form, setForm] = useState({
    'Nro Mesa': '',
    'Sección': '',
    'Circuito': '',
    'Votantes Habilitados': '',
    'Lista 503 Frente Defendemos LP': '',
    'Lista 501 Alianza LLA': '',
    'Lista 502 Frente FIT': '',
    'Lista 504 Frente Cambia LP': '',
    'Lista 13 MAS': '',
    'Votos Blanco': '',
    'Votos Nulos': '',
    'Votos Recurridos': '',
    'Suma Votos Emitidos': '',
    'Observaciones': ''
  })

  const handleChange = (e) => {
    const { name, value } = e.target
    const updatedForm = { ...form, [name]: value }

    if (['Lista 503 Frente Defendemos LP', 'Lista 501 Alianza LLA', 'Lista 502 Frente FIT', 'Lista 504 Frente Cambia LP', 'Lista 13 MAS', 'Votos Blanco', 'Votos Nulos', 'Votos Recurridos'].includes(name)) {
      const total = ['Lista 503 Frente Defendemos LP', 'Lista 501 Alianza LLA', 'Lista 502 Frente FIT', 'Lista 504 Frente Cambia LP', 'Lista 13 MAS', 'Votos Blanco', 'Votos Nulos', 'Votos Recurridos']
        .reduce((acc, key) => acc + Number(updatedForm[key] || 0), 0)
      updatedForm['Suma Votos Emitidos'] = total
    }

    setForm(updatedForm)
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    try {
      const res = await fetch('https://script.google.com/macros/s/AKfycbxpZQqVIJ0D2deCvet6Ph0o4U4YgMu5MHyuTjDYyqpnHZOUTINjy8GaD1yThZe4dgWJdw/exec', {
        method: 'POST',
        body: new URLSearchParams(form)
      })
      if (res.ok) {
        alert('Datos enviados correctamente ✅')
        setForm({ ...form, 'Observaciones': '' })
      } else {
        alert('Error al enviar los datos ❌')
      }
    } catch (error) {
      alert('Error al conectar con el servidor ❌')
    }
  }

  return (
    <form onSubmit={handleSubmit} className="w-full max-w-lg mt-4 p-4 bg-gray-50 rounded-xl shadow">
      <div className="grid grid-cols-2 gap-3">
        {Object.keys(form).map((key) => (
          key !== 'Observaciones' && (
            <label key={key} className="flex flex-col text-sm font-semibold text-gray-700">
              {key}
              <input
                type="text"
                name={key}
                value={form[key]}
                onChange={handleChange}
                className="border rounded p-1 text-gray-800"
              />
            </label>
          )
        ))}
      </div>
      <label className="flex flex-col text-sm font-semibold text-gray-700 mt-4">
        Observaciones
        <textarea
          name="Observaciones"
          value={form['Observaciones']}
          onChange={handleChange}
          className="border rounded p-2 text-gray-800"
        />
      </label>
      <button type="submit" className="mt-4 bg-violet-700 text-white px-4 py-2 rounded hover:bg-violet-800">
        Enviar
      </button>
    </form>
  )
}
