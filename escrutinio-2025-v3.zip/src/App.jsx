import React from 'react'
import Formulario from './components/Formulario'

export default function App() {
  return (
    <div className="min-h-screen bg-white flex flex-col items-center">
      <img src="/logo.png" alt="Logo PRO" className="w-32 mt-4" />
      <h1 className="text-2xl font-bold text-gray-800 my-2">Escrutinio 2025 - La Pampa</h1>
      <Formulario />
    </div>
  )
}
