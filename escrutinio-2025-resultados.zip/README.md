# Escrutinio 2025 - La Pampa (Carga + Resultados)

- Carga de datos con autocompletado por **Mesa** (Sección/Circuito desde "Lugares" CSV).
- Visualización de resultados:
  - **Por Sección** (totales por agrupación).
  - **Por Circuito** (totales y detalle por Mesa).
  - Gráficos de barras comparativos por agrupación.
- Envío/lectura vía Google Apps Script.

## Apps Script (Hoja "Mesas")
Agregá en tu Apps Script (mismo deployment) algo como:

function doGet(e) {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const hoja = ss.getSheetByName('Mesas'); // <-- nombre confirmado
  const datos = hoja.getDataRange().getValues();
  const headers = datos.shift();
  const out = datos.map(r => {
    const obj = {};
    headers.forEach((h,i)=> obj[String(h).trim()] = r[i]);
    return obj;
  });
  if (e && e.parameter && e.parameter.action === 'getData') {
    return ContentService.createTextOutput(JSON.stringify(out)).setMimeType(ContentService.MimeType.JSON);
  }
  return ContentService.createTextOutput('OK');
}

Asegurate que los encabezados incluyan: seccion, circuito, nro_mesa, votos_agrup1..5, votos_blanco, votos_nulos, votos_recurridos, total_emitidos (o similar).
