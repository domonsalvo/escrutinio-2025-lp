import React, { useEffect, useMemo, useState } from 'react'
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts'

const BASE_URL = 'https://script.google.com/macros/s/AKfycbxpZQqVIJ0D2deCvet6Ph0o4U4YgMu5MHyuTjDYyqpnHZOUTINjy8GaD1yThZe4dgWJdw/exec'
const N = v => { const n=parseInt(v,10); return Number.isFinite(n)?n:0 }

function norm(r){
  const g=(...keys)=>{
    for(const k of keys){ if(r[k]!==undefined) return r[k] }
    const low = Object.keys(r).find(h => keys.map(s=>String(s).toLowerCase()).includes(String(h).toLowerCase()))
    return low ? r[low] : undefined
  }
  return {
    seccion: g('Sección','Seccion','SECCION') || '',
    circuito: g('Circuito','CIRCUITO') || '',
    mesa: g('Nro Mesa','Mesa','MESA','nro_mesa') || '',
    a503: N(g('Lista 503 Frente Defendemos LP','Agrup1','Lista 503')),
    a501: N(g('Lista 501 Alianza LLA','Agrup2','Lista 501')),
    a502: N(g('Lista 502 Frente FIT','Agrup3','Lista 502')),
    a504: N(g('Lista 504 Frente Cambia LP','Agrup4','Lista 504')),
    a13:  N(g('Lista 13 MAS','Agrup5','Lista 13')),
    blanco: N(g('Votos Blanco','Blancos')),
    nulo: N(g('Votos Nulos','Nulos')),
    recurrido: N(g('Votos Recurridos','Recurridos')),
    emitidos: N(g('Suma Votos Emitidos','Total_Emitidos','Emitidos'))
  }
}

export default function Resultados(){
  const [rows, setRows] = useState([])
  const [vista, setVista] = useState('seccion')
  const [loading, setLoading] = useState(true)

  useEffect(()=>{
    (async()=>{
      try{
        const res = await fetch(`${BASE_URL}?action=getMesas`)
        const js = await res.json()
        setRows((Array.isArray(js)?js:[]).map(norm))
      }catch(e){ console.error(e) }
      finally{ setLoading(false) }
    })()
  },[])

  const porSeccion = useMemo(()=>{
    const map = new Map()
    rows.forEach(r=>{
      const k = r.seccion || '(sin sección)'
      if(!map.has(k)) map.set(k, [])
      map.get(k).push(r)
    })
    return Array.from(map.entries()).map(([sec, arr])=>{
      const t = arr.reduce((a,r)=>{
        a.a503+=r.a503; a.a501+=r.a501; a.a502+=r.a502; a.a504+=r.a504; a.a13+=r.a13;
        a.blanco+=r.blanco; a.nulo+=r.nulo; a.recurrido+=r.recurrido; a.emitidos+=r.emitidos; return a
      },{a503:0,a501:0,a502:0,a504:0,a13:0,blanco:0,nulo:0,recurrido:0,emitidos:0})
      return { seccion: sec, ...t }
    }).sort((a,b)=> String(a.seccion).localeCompare(String(b.seccion)))
  },[rows])

  const porCircuito = useMemo(()=>{
    const map = new Map()
    rows.forEach(r=>{
      const k = r.circuito || '(sin circuito)'
      if(!map.has(k)) map.set(k, [])
      map.get(k).push(r)
    })
    return Array.from(map.entries()).map(([circ, arr])=>{
      const total = arr.reduce((a,r)=>{
        a.a503+=r.a503; a.a501+=r.a501; a.a502+=r.a502; a.a504+=r.a504; a.a13+=r.a13;
        a.blanco+=r.blanco; a.nulo+=r.nulo; a.recurrido+=r.recurrido; a.emitidos+=r.emitidos; return a
      },{a503:0,a501:0,a502:0,a504:0,a13:0,blanco:0,nulo:0,recurrido:0,emitidos:0})
        const detalle = arr.slice().sort((a,b)=> N(a.mesa)-N(b.mesa))
      return { circuito: circ, total, detalle }
    }).sort((a,b)=> String(a.circuito).localeCompare(String(b.circuito)))
  },[rows])

  const dataBarSeccion = porSeccion.map(r=>({ 
    name: r.seccion, 
    'Lista 503': r.a503, 'Lista 501': r.a501, 'Lista 502': r.a502, 'Lista 504': r.a504, 'Lista 13': r.a13
  }))

  const totals = rows.reduce((a,r)=>{
    a.a503+=r.a503; a.a501+=r.a501; a.a502+=r.a502; a.a504+=r.a504; a.a13+=r.a13;
    a.blanco+=r.blanco; a.nulo+=r.nulo; a.recurrido+=r.recurrido; a.emitidos+=r.emitidos; return a
  },{a503:0,a501:0,a502:0,a504:0,a13:0,blanco:0,nulo:0,recurrido:0,emitidos:0})

  const pieData = [
    { name:'Lista 501', value: totals.a501, color:'#8A2BE2' },
    { name:'Lista 503', value: totals.a503, color:'#00BFFF' },
    { name:'Lista 504', value: totals.a504, color:'#E53935' },
    { name:'Lista 502', value: totals.a502, color:'#2E7D32' },
    { name:'Lista 13', value: totals.a13,  color:'#9E9E9E' },
    { name:'Blancos', value: totals.blanco, color:'#B0B0B0' },
    { name:'Nulos', value: totals.nulo, color:'#8B5E3C' },
    { name:'Recurridos', value: totals.recurrido, color:'#333333' }
  ]

  const totalVotos = totals.emitidos || pieData.reduce((s,x)=>s+x.value,0)

  function exportCSV(){
    const headers = ['Sección','Circuito','Mesa','Lista 503','Lista 501','Lista 502','Lista 504','Lista 13','Blancos','Nulos','Recurridos','Total emitidos']
    const out = [headers.join(',')]
    rows.forEach(r=>{
      out.push([r.seccion, r.circuito, r.mesa, r.a503, r.a501, r.a502, r.a504, r.a13, r.blanco, r.nulo, r.recurrido, r.emitidos].join(','))
    })
    out.push(['TOTAL','','', totals.a503, totals.a501, totals.a502, totals.a504, totals.a13, totals.blanco, totals.nulo, totals.recurrido, totals.emitidos].join(','))
    const blob = new Blob([out.join('\n')], { type:'text/csv;charset=utf-8;' })
    const url = URL.createObjectURL(blob); const a=document.createElement('a')
    a.href=url; a.download='resultados_escrutinio_2025.csv'; a.click(); URL.revokeObjectURL(url)
  }

  return (
    <div className="card" style={{overflow:'hidden'}}>
      <div style={{display:'flex', gap:8, marginBottom: 12}}>
        <button className={`tab ${vista==='seccion'?'active':''}`} onClick={()=>setVista('seccion')}>Por Sección</button>
        <button className={`tab ${vista==='circuito'?'active':''}`} onClick={()=>setVista('circuito')}>Por Circuito</button>
      </div>

      {loading && <div className="muted">Cargando…</div>}

      {!loading && vista==='seccion' && (
        <>
          <div style={{width:'100%', height:360}}>
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={dataBarSeccion} margin={{ top:10, right:30, left:0, bottom:0 }}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Bar dataKey="Lista 503" />
                <Bar dataKey="Lista 501" />
                <Bar dataKey="Lista 502" />
                <Bar dataKey="Lista 504" />
                <Bar dataKey="Lista 13" />
              </BarChart>
            </ResponsiveContainer>
          </div>

          <div style={{overflowX:'auto', marginTop: 12}}>
            <table className="table">
              <thead>
                <tr>
                  <th>Sección</th><th>Lista 503</th><th>Lista 501</th><th>Lista 502</th><th>Lista 504</th><th>Lista 13</th>
                  <th>Blanco</th><th>Nulo</th><th>Recurrido</th><th>Total Emitidos</th>
                </tr>
              </thead>
              <tbody>
                {porSeccion.map(r=> (
                  <tr key={r.seccion}>
                    <td>{r.seccion}</td><td>{r.a503}</td><td>{r.a501}</td><td>{r.a502}</td><td>{r.a504}</td><td>{r.a13}</td>
                    <td>{r.blanco}</td><td>{r.nulo}</td><td>{r.recurrido}</td><td><b>{r.emitidos}</b></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div className="center" style={{marginTop:14}}>
            <button className="btn" style={{width:'auto'}} onClick={exportCSV}>Exportar a CSV</button>
          </div>
        </>
      )}

      {!loading && vista==='circuito' && (
        <div style={{display:'flex', flexDirection:'column', gap:16}}>
          <div style={{width:'100%', height:360}}>
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie data={pieData} dataKey="value" nameKey="name" outerRadius={130} label />
                <Tooltip /><Legend />
                {pieData.map((e,i)=>(<Cell key={i} fill={e.color} />))}
              </PieChart>
            </ResponsiveContainer>
          </div>

          {porCircuito.map(block=> (
            <div key={block.circuito} className="card">
              <div style={{fontWeight:700, marginBottom:8}}>Circuito: {block.circuito}</div>
              <div style={{overflowX:'auto'}}>
                <table className="table">
                  <thead>
                    <tr>
                      <th>Mesa</th><th>Lista 503</th><th>Lista 501</th><th>Lista 502</th><th>Lista 504</th><th>Lista 13</th>
                      <th>Blanco</th><th>Nulo</th><th>Recurrido</th><th>Total Emitidos</th>
                    </tr>
                  </thead>
                  <tbody>
                    {block.detalle.map(m=> (
                      <tr key={m.mesa}>
                        <td>{m.mesa}</td><td>{m.a503}</td><td>{m.a501}</td><td>{m.a502}</td><td>{m.a504}</td><td>{m.a13}</td>
                        <td>{m.blanco}</td><td>{m.nulo}</td><td>{m.recurrido}</td><td><b>{m.emitidos}</b></td>
                      </tr>
                    ))}
                    <tr style={{background:'#f1f1f1', fontWeight:700}}>
                      <td>Total circuito</td>
                      <td>{block.total.a503}</td><td>{block.total.a501}</td><td>{block.total.a502}</td><td>{block.total.a504}</td><td>{block.total.a13}</td>
                      <td>{block.total.blanco}</td><td>{block.total.nulo}</td><td>{block.total.recurrido}</td><td>{block.total.emitidos}</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          ))}

          <div className="center">
            <button className="btn" style={{width:'auto'}} onClick={exportCSV}>Exportar a CSV</button>
          </div>
        </div>
      )}
    </div>
  )
}
