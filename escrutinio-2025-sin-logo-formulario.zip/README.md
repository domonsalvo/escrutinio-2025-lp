# Escrutinio 2025 - La Pampa (Final)
- Pestañas: **Cargar Datos**, **Ver Resultados**, **Resumen General**.
- Resumen incluye gráfico circular con votos + porcentaje y botón **Exportar a CSV** con fila de totales.
- Backend: Apps Script `action=getData` leyendo de la hoja **"Mesas"**.

## Dev
npm install
npm run dev

## Build
npm run build
